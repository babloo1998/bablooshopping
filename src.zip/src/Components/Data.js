export const storeProducts = [
    {
    id : 1,
    name : "Nike",
    price : 500,
    image: "Assets/img1.jpg",
    inCart: 0,
    count: 0,
    total: 0,
    defaultcolor : "Blue"
    },
    {
    id : 2,
    name : "Addidas",
    price : 100,
    image: "Assets/img2.jpg",
    inCart: 0,
    count: 0,
    total: 0,
    defaultcolor : "Red"
    },
    {
    id : 3,
    name : "Gas",
    price : 200,
    image: "Assets/img3.jpg",
    inCart: 0,
    count: 0,
    total: 0,
    defaultcolor : "Yellow"
    },
    {
    id : 4,
    name : "Cantabil",
    price : 300,
    image: "Assets/img1.jpg",
    inCart: 0,
    count: 0,
    total: 0,
    defaultcolor : "Blue"
    },
    {
    id : 5,
    name : "Van Heusen",
    price : 150,
    image: "Assets/img2.jpg",
    inCart: 0,
    count: 0,
    total: 0,
    defaultcolor : "Red"
    },
    {
    id : 6,
    name : "Louis Philipe",
    price : 100,
    image: "Assets/img3.jpg",
    inCart: 0,
    count: 0,
    total: 0,
    defaultcolor : "Yellow"
    },
    
    
    ];
    export const detailProduct = {
    id: 1,
    name: "Product Name Bla Bla",
    price: 9.99,
    image: "Assets/img1.jpg",
    inCart: 0,
    count: 0,
    total: 0,
    defaultcolor : "blue"
    };
    
    export const images = [
    {
    Blue : "Assets/img1.jpg",
    Red: "Assets/img2.jpg",
    Yellow : "Assets/img3.jpg"
    },
    ];
    
    export const color = [
    {
    Red: "Red",
    Blue: "Blue",
    Yellow: "Yellow",
    }
    ];